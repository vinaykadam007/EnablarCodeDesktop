// Write your code from here
// Write your code from here
createBox('b');
setPosition('b',0,0,-11);